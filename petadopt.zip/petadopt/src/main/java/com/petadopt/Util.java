package com.petadopt;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class Util {
    private Util() {}

    public static String q(String s) {
        if (s == null) return "null";
        StringBuilder b = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> {}
                case '\t' -> b.append("\\t");
                default -> { if (c < 0x20) b.append(String.format("\\u%04x", (int) c)); else b.append(c); }
            }
        }
        return b.append('"').toString();
    }

    public static void send(HttpServletResponse r, int code, String json) throws IOException {
        r.setStatus(code);
        r.setContentType("application/json");
        r.setCharacterEncoding("UTF-8");
        r.getWriter().write(json);
    }

    public static void err(HttpServletResponse r, int code, String msg) throws IOException {
        send(r, code, "{\"error\":" + q(msg) + "}");
    }

    public static String petJson(ResultSet rs) throws SQLException {
        return "{\"id\":" + rs.getInt("id") + ",\"name\":" + q(rs.getString("name"))
            + ",\"species\":" + q(rs.getString("species")) + ",\"breed\":" + q(rs.getString("breed"))
            + ",\"age\":" + rs.getBigDecimal("age_years") + ",\"gender\":" + q(rs.getString("gender"))
            + ",\"description\":" + q(rs.getString("description")) + ",\"imageUrl\":" + q(rs.getString("image_url"))
            + ",\"status\":" + q(rs.getString("status")) + "}";
    }

    // ---- password hashing (PBKDF2, no extra dependencies) ----
    private static byte[] pbkdf2(String pw, byte[] salt) throws Exception {
        KeySpec spec = new PBEKeySpec(pw.toCharArray(), salt, 120_000, 256);
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
    }

    public static String hash(String pw) throws Exception {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        Base64.Encoder e = Base64.getEncoder();
        return e.encodeToString(salt) + ":" + e.encodeToString(pbkdf2(pw, salt));
    }

    public static boolean verify(String pw, String stored) throws Exception {
        String[] p = stored.split(":");
        byte[] expected = Base64.getDecoder().decode(p[1]);
        return java.security.MessageDigest.isEqual(expected, pbkdf2(pw, Base64.getDecoder().decode(p[0])));
    }
}
