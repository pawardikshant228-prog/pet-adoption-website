package com.petadopt;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/api/auth/*")
public class AuthServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute("uid") == null) { Util.send(res, 200, "{\"user\":null}"); return; }
        Util.send(res, 200, "{\"user\":{\"id\":" + s.getAttribute("uid") + ",\"name\":" + Util.q((String) s.getAttribute("name")) + "}}");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();
        try {
            switch (path) {
                case "/register" -> register(req, res);
                case "/login" -> login(req, res);
                case "/logout" -> { HttpSession s = req.getSession(false); if (s != null) s.invalidate(); Util.send(res, 200, "{\"ok\":true}"); }
                default -> Util.err(res, 404, "Unknown action");
            }
        } catch (Exception e) {
            getServletContext().log("Auth error", e);
            Util.err(res, 500, "Something went wrong. Please try again.");
        }
    }

    private void register(HttpServletRequest req, HttpServletResponse res) throws Exception {
        String name = trim(req.getParameter("name")), email = trim(req.getParameter("email")).toLowerCase();
        String pw = req.getParameter("password") == null ? "" : req.getParameter("password");
        if (name.isEmpty() || name.length() > 100) { Util.err(res, 400, "Enter your name."); return; }
        if (!email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$") || email.length() > 150) { Util.err(res, 400, "Enter a valid email address."); return; }
        if (pw.length() < 8) { Util.err(res, 400, "Password must be at least 8 characters."); return; }
        try (Connection c = Db.get();
             PreparedStatement ps = c.prepareStatement("INSERT INTO users (name,email,password_hash) VALUES (?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name); ps.setString(2, email); ps.setString(3, Util.hash(pw));
            ps.executeUpdate();
            try (ResultSet k = ps.getGeneratedKeys()) { k.next(); startSession(req, res, k.getInt(1), name); }
        } catch (SQLIntegrityConstraintViolationException dup) {
            Util.err(res, 409, "An account with this email already exists.");
        }
    }

    private void login(HttpServletRequest req, HttpServletResponse res) throws Exception {
        String email = trim(req.getParameter("email")).toLowerCase();
        String pw = req.getParameter("password") == null ? "" : req.getParameter("password");
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement("SELECT id,name,password_hash FROM users WHERE email=?")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && Util.verify(pw, rs.getString("password_hash"))) startSession(req, res, rs.getInt("id"), rs.getString("name"));
                else Util.err(res, 401, "Incorrect email or password.");
            }
        }
    }

    private void startSession(HttpServletRequest req, HttpServletResponse res, int id, String name) throws IOException {
        req.getSession(true);
        req.changeSessionId(); // prevent session fixation
        HttpSession s = req.getSession();
        s.setAttribute("uid", id); s.setAttribute("name", name);
        Util.send(res, 200, "{\"user\":{\"id\":" + id + ",\"name\":" + Util.q(name) + "}}");
    }

    private static String trim(String s) { return s == null ? "" : s.trim(); }
}
