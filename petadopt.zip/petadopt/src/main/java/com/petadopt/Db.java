package com.petadopt;

import java.sql.*;

/** JDBC connection factory. Override with env vars DB_URL, DB_USER, DB_PASS. */
public final class Db {
    static {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch (ClassNotFoundException e) { throw new ExceptionInInitializerError(e); }
    }
    private static String env(String k, String d) { String v = System.getenv(k); return v == null ? d : v; }

    public static Connection get() throws SQLException {
        return DriverManager.getConnection(
            env("DB_URL", "jdbc:mysql://localhost:3306/petadopt?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"),
            env("DB_USER", "root"), env("DB_PASS", "root"));
    }
    private Db() {}
}
