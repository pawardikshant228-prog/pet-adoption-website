package com.petadopt;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/api/pets/*")
public class PetServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String path = req.getPathInfo();
        try (Connection c = Db.get()) {
            if (path == null || path.equals("/")) list(c, req, res); else detail(c, path.substring(1), res);
        } catch (SQLException e) {
            getServletContext().log("Pet error", e);
            Util.err(res, 500, "Could not load pets.");
        }
    }

    private void list(Connection c, HttpServletRequest req, HttpServletResponse res) throws SQLException, IOException {
        StringBuilder sql = new StringBuilder("SELECT * FROM pets WHERE 1=1");
        List<Object> args = new ArrayList<>();
        String species = req.getParameter("species"), q = req.getParameter("q"), status = req.getParameter("status");
        if (species != null && !species.isBlank()) { sql.append(" AND species=?"); args.add(species); }
        if (status != null && !status.isBlank()) { sql.append(" AND status=?"); args.add(status); }
        if (q != null && !q.isBlank()) { sql.append(" AND (name LIKE ? OR breed LIKE ? OR description LIKE ?)"); String l = "%" + q.trim() + "%"; args.add(l); args.add(l); args.add(l); }
        sql.append(" ORDER BY id DESC");
        try (PreparedStatement ps = c.prepareStatement(sql.toString())) {
            for (int i = 0; i < args.size(); i++) ps.setObject(i + 1, args.get(i));
            StringJoiner j = new StringJoiner(",", "{\"pets\":[", "]}");
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) j.add(Util.petJson(rs)); }
            Util.send(res, 200, j.toString());
        }
    }

    private void detail(Connection c, String idStr, HttpServletResponse res) throws SQLException, IOException {
        int id;
        try { id = Integer.parseInt(idStr); } catch (NumberFormatException e) { Util.err(res, 400, "Invalid pet id."); return; }
        try (PreparedStatement ps = c.prepareStatement("SELECT * FROM pets WHERE id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) Util.send(res, 200, Util.petJson(rs)); else Util.err(res, 404, "Pet not found.");
            }
        }
    }
}
