package com.petadopt;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.StringJoiner;

@WebServlet("/api/adoptions")
public class AdoptionServlet extends HttpServlet {

    private Integer uid(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        return s == null ? null : (Integer) s.getAttribute("uid");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Integer uid = uid(req);
        if (uid == null) { Util.err(res, 401, "Log in to see your requests."); return; }
        String sql = "SELECT a.id, a.status, a.message, a.created_at, p.id AS pet_id, p.name AS pet_name, p.species FROM adoption_requests a JOIN pets p ON p.id=a.pet_id WHERE a.user_id=? ORDER BY a.id DESC";
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, uid);
            StringJoiner j = new StringJoiner(",", "{\"requests\":[", "]}");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) j.add("{\"id\":" + rs.getInt("id") + ",\"status\":" + Util.q(rs.getString("status"))
                    + ",\"message\":" + Util.q(rs.getString("message")) + ",\"createdAt\":" + Util.q(rs.getString("created_at"))
                    + ",\"petId\":" + rs.getInt("pet_id") + ",\"petName\":" + Util.q(rs.getString("pet_name"))
                    + ",\"species\":" + Util.q(rs.getString("species")) + "}");
            }
            Util.send(res, 200, j.toString());
        } catch (SQLException e) {
            getServletContext().log("Adoption list error", e);
            Util.err(res, 500, "Could not load your requests.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        Integer uid = uid(req);
        if (uid == null) { Util.err(res, 401, "Log in to request an adoption."); return; }
        int petId;
        try { petId = Integer.parseInt(req.getParameter("petId")); } catch (Exception e) { Util.err(res, 400, "Invalid pet."); return; }
        String msg = req.getParameter("message") == null ? "" : req.getParameter("message").trim();
        if (msg.length() > 1000) { Util.err(res, 400, "Message is too long (max 1000 characters)."); return; }

        try (Connection c = Db.get()) {
            try (PreparedStatement ps = c.prepareStatement("SELECT status FROM pets WHERE id=?")) {
                ps.setInt(1, petId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) { Util.err(res, 404, "Pet not found."); return; }
                    if (!"AVAILABLE".equals(rs.getString(1))) { Util.err(res, 409, "This pet is no longer available."); return; }
                }
            }
            try (PreparedStatement ps = c.prepareStatement("INSERT INTO adoption_requests (user_id,pet_id,message) VALUES (?,?,?)")) {
                ps.setInt(1, uid); ps.setInt(2, petId); ps.setString(3, msg);
                ps.executeUpdate();
                Util.send(res, 201, "{\"ok\":true}");
            }
        } catch (SQLIntegrityConstraintViolationException dup) {
            Util.err(res, 409, "You have already requested this pet.");
        } catch (SQLException e) {
            getServletContext().log("Adoption error", e);
            Util.err(res, 500, "Could not save your request.");
        }
    }
}
