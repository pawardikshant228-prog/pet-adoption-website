const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const EMOJI = {Dog:'🐶', Cat:'🐱', Rabbit:'🐰', Bird:'🐦'};
let user = null;

async function api(path, opts) {
  const r = await fetch('api' + path, opts);
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Request failed');
  return d;
}
const post = (p, obj) => api(p, {
  method: 'POST',
  headers: {'Content-Type': 'application/x-www-form-urlencoded'},
  body: new URLSearchParams(obj)
});

function renderNav() {
  $('#nav').innerHTML = user
    ? `<span>Hi, ${esc(user.name)}</span><button class="ghost" id="myBtn">My requests</button><button class="ghost" id="outBtn">Log out</button>`
    : `<button class="ghost" id="inBtn">Log in</button><button id="upBtn">Create account</button>`;
  if (user) {
    $('#myBtn').onclick = showRequests;
    $('#outBtn').onclick = async () => { await post('/auth/logout', {}); user = null; renderNav(); };
  } else {
    $('#inBtn').onclick = () => showAuth('login');
    $('#upBtn').onclick = () => showAuth('register');
  }
}

async function loadPets() {
  const p = new URLSearchParams();
  if ($('#q').value.trim()) p.set('q', $('#q').value.trim());
  if ($('#species').value) p.set('species', $('#species').value);
  if ($('#avail').checked) p.set('status', 'AVAILABLE');
  try {
    const {pets} = await api('/pets?' + p);
    $('#grid').innerHTML = pets.length ? pets.map(card).join('') : '<p class="empty">No pets match these filters. Try a different species or clear the search.</p>';
    document.querySelectorAll('.pet').forEach(b => b.onclick = () => showPet(b.dataset.id));
  } catch (e) { $('#grid').innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
}

const pic = p => p.imageUrl ? `<img src="${esc(p.imageUrl)}" alt="${esc(p.name)}">` : (EMOJI[p.species] || '🐾');
const card = p => `<button class="pet" data-id="${p.id}"><div class="pic">${pic(p)}</div><div class="info">
  <h3>${esc(p.name)}</h3><div class="meta">${esc(p.breed || p.species)} · ${p.age} yr · ${esc(p.gender)}</div>
  <span class="badge ${p.status}">${p.status.toLowerCase()}</span></div></button>`;

async function showPet(id) {
  const p = await api('/pets/' + id);
  $('#petBody').innerHTML = `<h2>${esc(p.name)}</h2>
    <p class="meta">${esc(p.species)} · ${esc(p.breed || '')} · ${p.age} yr · ${esc(p.gender)}</p>
    <p>${esc(p.description)}</p>
    <form id="adoptForm" ${p.status !== 'AVAILABLE' ? 'hidden' : ''}>
      <label>Tell us about your home and why you'd like to adopt ${esc(p.name)}
        <textarea name="message" rows="4" maxlength="1000"></textarea></label>
      <div class="err" id="adoptErr"></div>
      <div class="row"><button type="button" class="ghost" id="closePet">Close</button><button>Send adoption request</button></div>
    </form>
    ${p.status !== 'AVAILABLE' ? '<div class="row"><button class="ghost" id="closePet">Close</button></div>' : ''}`;
  $('#closePet').onclick = () => $('#petDlg').close();
  const f = $('#adoptForm');
  f.onsubmit = async e => {
    e.preventDefault();
    if (!user) { $('#petDlg').close(); return showAuth('login'); }
    try {
      await post('/adoptions', {petId: p.id, message: f.message.value});
      $('#petBody').innerHTML = `<h2>Request sent</h2><p>We received your request for ${esc(p.name)}. Track it under My requests.</p><div class="row"><button id="closePet">Done</button></div>`;
      $('#closePet').onclick = () => $('#petDlg').close();
    } catch (er) { $('#adoptErr').textContent = er.message; }
  };
  $('#petDlg').showModal();
}

function showAuth(mode) {
  const reg = mode === 'register';
  $('#authBody').innerHTML = `<h2>${reg ? 'Create your account' : 'Log in'}</h2>
    <form id="authForm">
      ${reg ? '<label>Name<input name="name" required maxlength="100" autocomplete="name"></label>' : ''}
      <label>Email<input name="email" type="email" required autocomplete="email"></label>
      <label>Password${reg ? ' (8+ characters)' : ''}<input name="password" type="password" required minlength="${reg ? 8 : 1}" autocomplete="${reg ? 'new-password' : 'current-password'}"></label>
      <div class="err" id="authErr"></div>
      <div class="row"><button type="button" class="ghost" id="cancelAuth">Cancel</button><button>${reg ? 'Create account' : 'Log in'}</button></div>
    </form>`;
  $('#cancelAuth').onclick = () => $('#authDlg').close();
  $('#authForm').onsubmit = async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    try { user = (await post('/auth/' + mode, data)).user; renderNav(); $('#authDlg').close(); }
    catch (er) { $('#authErr').textContent = er.message; }
  };
  $('#authDlg').showModal();
}

async function showRequests() {
  try {
    const {requests} = await api('/adoptions');
    $('#reqBody').innerHTML = `<h2>My adoption requests</h2>` + (requests.length
      ? `<ul class="reqs">${requests.map(r => `<li><strong>${esc(r.petName)}</strong> <span class="badge">${r.status.toLowerCase()}</span><div class="meta">${esc(r.createdAt)}</div></li>`).join('')}</ul>`
      : '<p>You have not requested any pets yet. Pick one from the list to get started.</p>')
      + '<div class="row"><button id="closeReq">Close</button></div>';
    $('#closeReq').onclick = () => $('#reqDlg').close();
    $('#reqDlg').showModal();
  } catch (e) { alert(e.message); }
}

let t;
$('#q').oninput = () => { clearTimeout(t); t = setTimeout(loadPets, 250); };
$('#species').onchange = $('#avail').onchange = loadPets;
api('/auth/me').then(d => { user = d.user; renderNav(); }).catch(renderNav);
loadPets();
