# Hearth & Paws: pet adoption (Java 17, Jakarta Servlet 6, JDBC, MySQL, Tomcat 10.1)

1. Create DB:      mysql -u root -p < sql/schema.sql
2. (Optional) set env vars DB_URL, DB_USER, DB_PASS before starting Tomcat (defaults: localhost:3306/petadopt, root/root).
3. Build:          mvn clean package
4. Deploy:         copy target/petadopt.war into Tomcat 10.1 `webapps/`, start Tomcat
5. Open:           http://localhost:8080/petadopt/

Endpoints: GET /api/pets?species=&q=&status= | GET /api/pets/{id} | POST /api/auth/register|login|logout | GET /api/auth/me | GET/POST /api/adoptions
