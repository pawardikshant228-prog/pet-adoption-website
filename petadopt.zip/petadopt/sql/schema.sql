CREATE DATABASE IF NOT EXISTS petadopt CHARACTER SET utf8mb4;
USE petadopt;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE pets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  species VARCHAR(30) NOT NULL,
  breed VARCHAR(80),
  age_years DECIMAL(4,1) NOT NULL,
  gender VARCHAR(10) NOT NULL,
  description TEXT,
  image_url VARCHAR(255),
  status ENUM('AVAILABLE','PENDING','ADOPTED') NOT NULL DEFAULT 'AVAILABLE'
);

CREATE TABLE adoption_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  pet_id INT NOT NULL,
  message TEXT,
  status ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (user_id, pet_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (pet_id) REFERENCES pets(id)
);

INSERT INTO pets (name,species,breed,age_years,gender,description) VALUES
('Biscuit','Dog','Labrador mix',2.0,'Male','Friendly, loves fetch and long walks. Good with kids.'),
('Mochi','Cat','Indian Shorthair',1.5,'Female','Calm lap cat who purrs the moment you sit down.'),
('Rocky','Dog','Indie',4.0,'Male','Gentle senior-ish boy, house trained and quiet.'),
('Luna','Cat','Persian',3.0,'Female','Needs regular grooming; very affectionate.'),
('Clover','Rabbit','Dutch',1.0,'Female','Curious and social. Litter trained.'),
('Kiwi','Bird','Budgerigar',0.8,'Male','Chirpy and loves to whistle along.');
